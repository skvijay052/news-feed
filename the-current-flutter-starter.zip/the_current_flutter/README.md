# The Current — Flutter News App Starter

A Flutter Android app starter for combining the existing Tamil and English news sites:

- https://tamilnews-feed.netlify.app/
- https://newsfeed-current.netlify.app/

## Important integration note

This starter includes a polished native-style UI, language/category filters, search, article reader, bookmarks, sample fallback stories, and a GitHub Actions APK workflow.

The two websites are live HTML sites. Their public pages do not establish a stable JSON API contract. **Before connecting live stories, identify the existing CMS/API or add a small JSON feed endpoint to the website backend.** Do not rely on scraping the rendered HTML as a permanent API.

The app expects a JSON endpoint that returns either a list of articles or `{ "articles": [...] }`. Configure endpoints in `lib/news_repository.dart`:

```dart
static const tamilFeedUrl = String.fromEnvironment(
  'TAMIL_FEED_URL',
  defaultValue: '',
);
static const englishFeedUrl = String.fromEnvironment(
  'ENGLISH_FEED_URL',
  defaultValue: '',
);
```

Each article object should contain:
- `id` (string)
- `title` (string)
- `url` (absolute article URL)
- `language` (`ta` or `en`)
- optional `summary`, `imageUrl`, `source`, `category`, `publishedAt`

Example:
```json
{
  "articles": [
    {
      "id": "story-001",
      "title": "Sample headline",
      "summary": "Short summary",
      "url": "https://example.com/article",
      "imageUrl": "https://example.com/image.jpg",
      "source": "Publisher",
      "category": "Tamil Nadu",
      "language": "ta",
      "publishedAt": "2026-10-21T10:00:00Z"
    }
  ]
}
```

If no feed URL is configured or the request fails, the app displays clearly labelled sample stories so you can develop the UI before connecting the data.

## Run locally

1. Install Flutter and Android Studio: https://docs.flutter.dev/get-started/install
2. Create the Android platform scaffolding once:
   ```bash
   flutter create --platforms=android --org com.thecurrent.news .
   ```
   If Flutter asks to overwrite `lib/main.dart`, keep the starter's `lib/` files.
3. Install dependencies:
   ```bash
   flutter pub get
   ```
4. Run:
   ```bash
   flutter run
   ```
5. To connect your live feeds:
   ```bash
   flutter run \
     --dart-define=TAMIL_FEED_URL=https://YOUR-DOMAIN.example/api/tamil-news \
     --dart-define=ENGLISH_FEED_URL=https://YOUR-DOMAIN.example/api/english-news
   ```

## Build APK

```bash
flutter build apk --release \
  --dart-define=TAMIL_FEED_URL=https://YOUR-DOMAIN.example/api/tamil-news \
  --dart-define=ENGLISH_FEED_URL=https://YOUR-DOMAIN.example/api/english-news
```

APK output:
`build/app/outputs/flutter-apk/app-release.apk`

For Google Play, prefer a signed App Bundle:
```bash
flutter build appbundle --release
```

## GitHub Actions

Push this folder to a GitHub repository. The workflow `.github/workflows/build-apk.yml` builds a debug APK and uploads it as a downloadable workflow artifact. It does not publish the APK automatically.

## Recommended next integration step

Inspect the source code/repository or CMS that generates both Netlify sites. Expose a small read-only JSON endpoint from that source and map its actual fields in `NewsArticle.fromJson`. Keep article URLs linking to the original publisher. Confirm image, headline, excerpt and syndication rights before republishing full content or images.
