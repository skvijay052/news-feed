class NewsArticle {
  const NewsArticle({
    required this.id,
    required this.title,
    required this.url,
    required this.language,
    this.summary = '',
    this.imageUrl = '',
    this.source = 'The Current',
    this.category = 'Latest',
    this.publishedAt,
  });

  final String id;
  final String title;
  final String url;
  final String language; // ta or en
  final String summary;
  final String imageUrl;
  final String source;
  final String category;
  final DateTime? publishedAt;

  factory NewsArticle.fromJson(Map<String, dynamic> json, String fallbackLanguage) {
    DateTime? parsedDate;
    final rawDate = json['publishedAt'] ?? json['published_at'] ?? json['date'];
    if (rawDate != null) parsedDate = DateTime.tryParse(rawDate.toString());

    return NewsArticle(
      id: (json['id'] ?? json['url'] ?? json['link'] ?? json['title'] ?? '').toString(),
      title: (json['title'] ?? json['headline'] ?? '').toString(),
      url: (json['url'] ?? json['link'] ?? '').toString(),
      language: (json['language'] ?? fallbackLanguage).toString(),
      summary: (json['summary'] ?? json['description'] ?? json['excerpt'] ?? '').toString(),
      imageUrl: (json['imageUrl'] ?? json['image_url'] ?? json['image'] ?? '').toString(),
      source: (json['source'] ?? json['publisher'] ?? 'The Current').toString(),
      category: (json['category'] ?? 'Latest').toString(),
      publishedAt: parsedDate,
    );
  }
}
