import 'dart:convert';
import 'package:http/http.dart' as http;
import 'news_article.dart';

class NewsRepository {
  static const tamilFeedUrl = String.fromEnvironment('TAMIL_FEED_URL', defaultValue: '');
  static const englishFeedUrl = String.fromEnvironment('ENGLISH_FEED_URL', defaultValue: '');

  Future<List<NewsArticle>> fetchAll() async {
    final results = await Future.wait([
      _fetchOne(tamilFeedUrl, 'ta'),
      _fetchOne(englishFeedUrl, 'en'),
    ]);
    final articles = results.expand((items) => items).toList()
      ..sort((a, b) => (b.publishedAt ?? DateTime(2000))
          .compareTo(a.publishedAt ?? DateTime(2000)));
    return articles.isEmpty ? sampleArticles : articles;
  }

  Future<List<NewsArticle>> _fetchOne(String endpoint, String language) async {
    if (endpoint.trim().isEmpty) return const [];
    try {
      final response = await http.get(Uri.parse(endpoint)).timeout(const Duration(seconds: 12));
      if (response.statusCode != 200) return const [];
      final decoded = jsonDecode(utf8.decode(response.bodyBytes));
      final rawList = decoded is List ? decoded : (decoded is Map ? decoded['articles'] : null);
      if (rawList is! List) return const [];
      return rawList
          .whereType<Map>()
          .map((item) => NewsArticle.fromJson(Map<String, dynamic>.from(item), language))
          .where((item) => item.title.trim().isNotEmpty && item.url.startsWith('http'))
          .toList();
    } catch (_) {
      return const [];
    }
  }

  // UI development fallback only; replace with your live JSON feeds.
  static final List<NewsArticle> sampleArticles = [
    NewsArticle(
      id: 'demo-ta-1',
      title: 'தமிழ்நாட்டின் முக்கிய செய்திகள் — இன்றைய தலைப்புகள்',
      summary: 'உங்கள் தமிழ் செய்தி feed இணைக்கப்பட்டதும் இங்கு நேரடி செய்திகள் தோன்றும்.',
      url: 'https://tamilnews-feed.netlify.app/',
      language: 'ta', source: 'The Current Tamil', category: 'தமிழ்நாடு',
      publishedAt: DateTime.now(),
    ),
    NewsArticle(
      id: 'demo-en-1',
      title: 'Today’s top stories from India and around the world',
      summary: 'Connect your English news feed to replace this development sample with live headlines.',
      url: 'https://newsfeed-current.netlify.app/',
      language: 'en', source: 'The Current', category: 'Top Stories',
      publishedAt: DateTime.now(),
    ),
    NewsArticle(
      id: 'demo-ta-2',
      title: 'தொழில்நுட்பம், வணிகம் மற்றும் விளையாட்டு செய்திகள்',
      summary: 'Browse the latest stories by category in one combined app.',
      url: 'https://tamilnews-feed.netlify.app/',
      language: 'ta', source: 'The Current Tamil', category: 'தொழில்நுட்பம்',
      publishedAt: DateTime.now().subtract(const Duration(minutes: 35)),
    ),
    NewsArticle(
      id: 'demo-en-2',
      title: 'Technology and business updates you should know',
      summary: 'A sample card showing the English typography and story layout.',
      url: 'https://newsfeed-current.netlify.app/',
      language: 'en', source: 'The Current', category: 'Technology',
      publishedAt: DateTime.now().subtract(const Duration(minutes: 50)),
    ),
  ];
}
