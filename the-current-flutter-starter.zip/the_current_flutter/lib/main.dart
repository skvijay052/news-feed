import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import 'news_article.dart';
import 'news_repository.dart';

void main() => runApp(const TheCurrentApp());

const ink = Color(0xFF171717);
const paper = Color(0xFFF7F7F5);
const accent = Color(0xFFC62828);

class TheCurrentApp extends StatelessWidget {
  const TheCurrentApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'The Current',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: paper,
        colorScheme: ColorScheme.fromSeed(seedColor: accent, brightness: Brightness.light),
        appBarTheme: const AppBarTheme(backgroundColor: paper, foregroundColor: ink, centerTitle: false),
        cardTheme: CardThemeData(color: Colors.white, elevation: 0, margin: EdgeInsets.zero, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
        fontFamily: null,
      ),
      home: const NewsHome(),
    );
  }
}

class NewsHome extends StatefulWidget {
  const NewsHome({super.key});
  @override
  State<NewsHome> createState() => _NewsHomeState();
}

class _NewsHomeState extends State<NewsHome> {
  final repository = NewsRepository();
  final searchController = TextEditingController();
  List<NewsArticle> all = [];
  Set<String> saved = {};
  bool loading = true;
  bool searchOpen = false;
  int tab = 0;
  String language = 'all';
  String category = 'All';

  final categories = const {
    'all': ['All', 'தமிழ்நாடு', 'இந்தியா', 'World', 'Technology', 'Business', 'Sports', 'Entertainment'],
    'ta': ['All', 'தமிழ்நாடு', 'இந்தியா', 'உலகம்', 'தொழில்நுட்பம்', 'வணிகம்', 'விளையாட்டு', 'பொழுதுபோக்கு'],
    'en': ['All', 'India', 'World', 'Technology', 'Business', 'Sports', 'Entertainment', 'Lifestyle'],
  };

  @override
  void initState() {
    super.initState();
    load();
  }

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final stories = await repository.fetchAll();
    if (!mounted) return;
    setState(() {
      all = stories;
      saved = prefs.getStringList('saved_article_ids')?.toSet() ?? {};
      loading = false;
    });
  }

  Future<void> toggleSaved(NewsArticle article) async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      if (!saved.add(article.id)) saved.remove(article.id);
    });
    await prefs.setStringList('saved_article_ids', saved.toList());
  }

  List<NewsArticle> get visible {
    Iterable<NewsArticle> items = tab == 2 ? all.where((a) => saved.contains(a.id)) : all;
    if (language != 'all') items = items.where((a) => a.language == language);
    if (category != 'All') items = items.where((a) => a.category.toLowerCase() == category.toLowerCase());
    final q = searchController.text.trim().toLowerCase();
    if (q.isNotEmpty) items = items.where((a) => '${a.title} ${a.summary} ${a.source} ${a.category}'.toLowerCase().contains(q));
    return items.toList();
  }

  @override
  Widget build(BuildContext context) {
    final stories = visible;
    return Scaffold(
      appBar: AppBar(
        title: searchOpen
            ? TextField(controller: searchController, autofocus: true, onChanged: (_) => setState(() {}),
                decoration: const InputDecoration(hintText: 'Search news / செய்திகளைத் தேடுங்கள்', border: InputBorder.none))
            : const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('THE CURRENT', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2, fontSize: 20)),
                Text('Tamil + English news', style: TextStyle(fontSize: 11, color: Colors.black54)),
              ]),
        actions: [
          IconButton(
            tooltip: 'Search',
            onPressed: () => setState(() {
              searchOpen = !searchOpen;
              if (!searchOpen) searchController.clear();
            }),
            icon: Icon(searchOpen ? Icons.close_rounded : Icons.search_rounded),
          ),
          IconButton(tooltip: 'Refresh', onPressed: () { setState(() => loading = true); load(); }, icon: const Icon(Icons.refresh_rounded)),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: load,
        child: CustomScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          slivers: [
            SliverToBoxAdapter(child: _languagePicker()),
            if (tab == 3)
              SliverToBoxAdapter(child: _websites())
            else ...[
            if (tab == 0 && stories.isNotEmpty)
              SliverToBoxAdapter(child: _featured(stories.first)),
            SliverToBoxAdapter(child: _sectionHeader(tab == 2 ? 'Saved stories' : 'Latest stories', 'LATEST • இப்போதைய செய்திகள்')),
            if (loading)
              const SliverFillRemaining(child: Center(child: CircularProgressIndicator()))
            else if (stories.isEmpty)
              SliverFillRemaining(hasScrollBody: false, child: _emptyState())
            else
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                sliver: SliverList.separated(
                  itemCount: stories.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 12),
                  itemBuilder: (context, index) => _storyCard(stories[index]),
                ),
              ),
            ],
          ],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (value) => setState(() => tab = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home_rounded), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.grid_view_rounded), label: 'Explore'),
          NavigationDestination(icon: Icon(Icons.bookmark_border_rounded), selectedIcon: Icon(Icons.bookmark_rounded), label: 'Saved'),
          NavigationDestination(icon: Icon(Icons.language_rounded), label: 'Websites'),
        ],
      ),
    );
  }

  Widget _languagePicker() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          _pill('All news', language == 'all', () => setState(() { language = 'all'; category = 'All'; })),
          const SizedBox(width: 8),
          _pill('தமிழ்', language == 'ta', () => setState(() { language = 'ta'; category = 'All'; })),
          const SizedBox(width: 8),
          _pill('English', language == 'en', () => setState(() { language = 'en'; category = 'All'; })),
        ]),
        const SizedBox(height: 12),
        SizedBox(
          height: 38,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: (categories[language] ?? categories['all']!).length,
            separatorBuilder: (_, __) => const SizedBox(width: 8),
            itemBuilder: (context, i) {
              final item = (categories[language] ?? categories['all']!)[i];
              return _pill(item, category == item, () => setState(() => category = item));
            },
          ),
        ),
      ]),
    );
  }

  Widget _pill(String label, bool selected, VoidCallback onTap) => ChoiceChip(
    label: Text(label, style: TextStyle(fontWeight: FontWeight.w600, color: selected ? Colors.white : ink, fontSize: 12)),
    selected: selected,
    onSelected: (_) => onTap(),
    showCheckmark: false,
    selectedColor: ink,
    backgroundColor: Colors.white,
    side: BorderSide(color: selected ? ink : const Color(0xFFE5E5E5)),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
    padding: const EdgeInsets.symmetric(horizontal: 6),
  );

  Widget _featured(NewsArticle article) => Padding(
    padding: const EdgeInsets.fromLTRB(16, 0, 16, 22),
    child: InkWell(
      borderRadius: BorderRadius.circular(22),
      onTap: () => _openArticle(article),
      child: Container(
        decoration: BoxDecoration(color: ink, borderRadius: BorderRadius.circular(22)),
        clipBehavior: Clip.antiAlias,
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          if (article.imageUrl.isNotEmpty)
            CachedNetworkImage(imageUrl: article.imageUrl, height: 190, width: double.infinity, fit: BoxFit.cover,
              errorWidget: (_, __, ___) => _imagePlaceholder(height: 190))
          else
            _imagePlaceholder(height: 150, dark: true),
          Padding(
            padding: const EdgeInsets.all(18),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(color: accent, borderRadius: BorderRadius.circular(20)),
                child: const Text('TOP STORY • முக்கிய செய்தி', style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold))),
              const SizedBox(height: 12),
              Text(article.title, maxLines: 3, overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: Colors.white, fontSize: 21, height: 1.3, fontWeight: FontWeight.w800)),
              if (article.summary.isNotEmpty) ...[
                const SizedBox(height: 8),
                Text(article.summary, maxLines: 2, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Colors.white70, fontSize: 13, height: 1.45)),
              ],
              const SizedBox(height: 12),
              Text('${article.source}  •  ${_time(article)}', style: const TextStyle(color: Colors.white60, fontSize: 11)),
            ]),
          ),
        ]),
      ),
    ),
  );

  Widget _sectionHeader(String title, String eyebrow) => Padding(
    padding: const EdgeInsets.fromLTRB(18, 2, 18, 14),
    child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(eyebrow, style: const TextStyle(color: accent, fontWeight: FontWeight.w800, letterSpacing: .7, fontSize: 10)),
        const SizedBox(height: 4),
        Text(title, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w900, color: ink)),
      ])),
      const Icon(Icons.arrow_downward_rounded, size: 19),
    ]),
  );

  Widget _storyCard(NewsArticle article) => Card(
    child: InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: () => _openArticle(article),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: article.imageUrl.isNotEmpty
              ? CachedNetworkImage(imageUrl: article.imageUrl, width: 104, height: 112, fit: BoxFit.cover,
                  errorWidget: (_, __, ___) => _imagePlaceholder(width: 104, height: 112))
              : _imagePlaceholder(width: 104, height: 112),
          ),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Flexible(child: Text(article.category.toUpperCase(), maxLines: 1, overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 9, fontWeight: FontWeight.w900, color: accent, letterSpacing: .5))),
              const Spacer(),
              IconButton(
                constraints: const BoxConstraints.tightFor(width: 30, height: 30),
                padding: EdgeInsets.zero,
                onPressed: () => toggleSaved(article),
                icon: Icon(saved.contains(article.id) ? Icons.bookmark_rounded : Icons.bookmark_border_rounded, size: 19),
              ),
            ]),
            Text(article.title, maxLines: 3, overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, height: 1.32, color: ink)),
            if (article.summary.isNotEmpty) ...[
              const SizedBox(height: 5),
              Text(article.summary, maxLines: 2, overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 11, height: 1.35, color: Colors.black54)),
            ],
            const SizedBox(height: 8),
            Text('${article.source}  ·  ${_time(article)}', maxLines: 1, overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 10, color: Colors.black54)),
          ])),
        ]),
      ),
    ),
  );

  Widget _imagePlaceholder({double width = double.infinity, double height = 130, bool dark = false}) => Container(
    width: width, height: height, color: dark ? const Color(0xFF292929) : const Color(0xFFE8E8E5),
    alignment: Alignment.center,
    child: Icon(Icons.newspaper_rounded, size: 34, color: dark ? Colors.white38 : Colors.black26),
  );

  Widget _emptyState() => Center(
    child: Padding(padding: const EdgeInsets.all(32), child: Column(mainAxisSize: MainAxisSize.min, children: [
      const Icon(Icons.article_outlined, size: 48, color: Colors.black38),
      const SizedBox(height: 12),
      const Text('No stories found', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 6),
      const Text('Try another language or category, or connect the live news feed.', textAlign: TextAlign.center,
        style: TextStyle(color: Colors.black54)),
      const SizedBox(height: 12),
      OutlinedButton(onPressed: () => setState(() { language = 'all'; category = 'All'; searchController.clear(); tab = 0; }), child: const Text('Show all news')),
    ])),
  );

  String _time(NewsArticle article) {
    if (article.publishedAt == null) return 'Latest';
    final difference = DateTime.now().difference(article.publishedAt!.toLocal());
    if (difference.inMinutes < 1) return 'Now';
    if (difference.inMinutes < 60) return '${difference.inMinutes}m ago';
    if (difference.inHours < 24) return '${difference.inHours}h ago';
    return DateFormat('d MMM').format(article.publishedAt!.toLocal());
  }

  Future<void> _openArticle(NewsArticle article) async {
    if (article.url.isEmpty) return;
    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => ArticlePage(article: article, isSaved: saved.contains(article.id), onSave: () => toggleSaved(article))));
  }

  Widget _websites() => Padding(
    padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Your news sources', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900)),
      const SizedBox(height: 6),
      const Text('Open either existing website for the full web experience.', style: TextStyle(color: Colors.black54)),
      const SizedBox(height: 16),
      Card(child: _websiteButton('The Current — தமிழ்', 'https://tamilnews-feed.netlify.app/')),
      const SizedBox(height: 10),
      Card(child: _websiteButton('The Current — English', 'https://newsfeed-current.netlify.app/')),
    ]),
  );

  Widget _websiteButton(String title, String url) => ListTile(
    leading: const CircleAvatar(child: Icon(Icons.public_rounded)),
    title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
    subtitle: Text(url),
    trailing: const Icon(Icons.open_in_new_rounded),
    onTap: () async { final uri = Uri.parse(url); if (await canLaunchUrl(uri)) await launchUrl(uri, mode: LaunchMode.externalApplication); },
  );
}

class ArticlePage extends StatelessWidget {
  const ArticlePage({super.key, required this.article, required this.isSaved, required this.onSave});
  final NewsArticle article;
  final bool isSaved;
  final VoidCallback onSave;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Story'),
        actions: [
          IconButton(onPressed: onSave, icon: Icon(isSaved ? Icons.bookmark_rounded : Icons.bookmark_border_rounded)),
          IconButton(onPressed: () async {
            final uri = Uri.parse(article.url);
            if (await canLaunchUrl(uri)) await launchUrl(uri, mode: LaunchMode.externalApplication);
          }, icon: const Icon(Icons.open_in_new_rounded)),
        ],
      ),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        Text(article.category.toUpperCase(), style: const TextStyle(color: accent, fontWeight: FontWeight.w900, letterSpacing: 1)),
        const SizedBox(height: 10),
        Text(article.title, style: const TextStyle(fontSize: 28, height: 1.22, fontWeight: FontWeight.w900)),
        const SizedBox(height: 12),
        Text('${article.source}  ·  ${article.language == 'ta' ? 'தமிழ்' : 'English'}  ·  ${article.publishedAt == null ? 'Latest' : DateFormat('d MMM yyyy, h:mm a').format(article.publishedAt!.toLocal())}',
          style: const TextStyle(color: Colors.black54, fontSize: 12)),
        const SizedBox(height: 20),
        if (article.imageUrl.isNotEmpty)
          ClipRRect(borderRadius: BorderRadius.circular(18), child: CachedNetworkImage(imageUrl: article.imageUrl, fit: BoxFit.cover,
            errorWidget: (_, __, ___) => const SizedBox(height: 150, child: Center(child: Icon(Icons.image_not_supported_outlined)))))
        else
          Container(height: 150, decoration: BoxDecoration(color: const Color(0xFFE8E8E5), borderRadius: BorderRadius.circular(18)),
            child: const Icon(Icons.newspaper_rounded, size: 48, color: Colors.black26)),
        const SizedBox(height: 20),
        Text(article.summary.isEmpty
            ? 'Read the full article on the original publisher’s website. This app keeps the story linked to its source.'
            : article.summary,
          style: const TextStyle(fontSize: 17, height: 1.65)),
        const SizedBox(height: 22),
        FilledButton.icon(
          onPressed: () async { final uri = Uri.parse(article.url); if (await canLaunchUrl(uri)) await launchUrl(uri, mode: LaunchMode.externalApplication); },
          icon: const Icon(Icons.open_in_new_rounded),
          label: const Text('Read full story on source website'),
        ),
        const SizedBox(height: 12),
        const Text('The Current brings Tamil and English headlines together. Full story text remains on the original source unless your content rights and feed provide permission to republish it.',
          style: TextStyle(color: Colors.black54, fontSize: 12, height: 1.45)),
      ]),
    );
  }
}
